<!DOCTYPE html>
<html>
    <head>
        <title>Ready Skin </title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
        <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
        <script type="text/javascript" src="myscript.js"></script>
    </head>
</html>


<?php
include "db.php";

//var_dump($_GET);exit;
//isset($_GET["prod_id"])?$_GET["prod_id"]:null;
$pid = $_GET["prod_id"];



//select products based on specific product id
    $sql="SELECT * FROM products WHERE idProd ='$pid'";
    $product = $connection->query($sql)->fetch_assoc();

        if(!$product){
            echo "Product Not find!!";exit;

        }
  
         $prod_id = $product["idProd"];
         $prod_category = $product["categoryProd"];
         $prod_volume = $product["volumeProd"];
         $prod_title = $product['titleProd'];
         $prod_price = $product["priceProd"];
         $prod_description = $product["descriptionProd"];
         $prod_image = $product["imageProd"];
         $prod_brand= $product["brandProduct"];
         
      echo "

      <div class='col-md-10'>
        <div class='panel panel-default'>
            <div class='panel-heading'>$prod_description</div>
                <div class='panel-body' style=' height: auto; overflow: hidden;'><img class='img-responsive' src='images/$prod_image'/></div>
                    <div class='panel-heading'>$prod_price 
                    <button style='float:right;' class='btn btn-info btn-xs'>Add To Cart</button>
                    </div>
                </div>    
            </div>
            ";
     


?>