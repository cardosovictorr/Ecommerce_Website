<?php
include "db.php";

$pid = $_POST["prod_id"];
//select products based on specific product id
$sql="SELECT * FROM product WHERE idProd ='$pid'";
$results= mysqli_query($connection,$sql);

 while($row = mysqli_fetch_array($results)){
     $prod_id = $row["idProd"];
     $prod_category = $row["categoryProd"];
     $prod_volume = $row["volumeProd"];
     $prod_title = $row['titleProd'];
     $prod_price = $row["priceProd"];
     $prod_description = $row["descriptionProd"];
     $prod_image = $row["imageProd"];
     $prod_brand= $row["brandProduct"];
  echo "

  <div class='col-md-10'>
                <div class='panel panel-default'>
                  <div class='panel-heading'>$prod_description</div>
                    <div class='panel-body' style=' height: auto; overflow: hidden;'><img class='img-responsive' src='images/$prod_image'/></div>
                     <div class='panel-heading'>$prod_price 
                      <button style='float:right;' class='btn btn-info btn-xs'>Add To Cart</button>
                    </div>
                </div>    
        </div>
        ";
 }

?>