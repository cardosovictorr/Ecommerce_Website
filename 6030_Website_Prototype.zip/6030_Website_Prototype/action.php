<?php
session_start();
$_SESSION["uid"]="123";
include "db.php";
if(isset($_POST["category"])){
$cat_sql="SELECT * FROM category ORDER BY id ";
$C_results= mysqli_query($connection,$cat_sql);
if(mysqli_num_rows($C_results) > 0){
    echo "<ul class='list-group list-group-flush'><h4>Filter Poducts</h4>";
    while($row = mysqli_fetch_array($C_results)){
      $cat_id = $row["id"];
      $cat_title = $row["cat_title"];
      echo "<li class='list-group-item '><a href='#' class='category' cid='$cat_id' >$cat_title</a></li>";
     
  }   
  } echo "</ul>";
}

/* The below code will select the products and display them in random way on the shopping page
*/


if(isset($_POST["products"])){
    
      $prod_sql="SELECT * FROM products ORDER BY RAND() LIMIT 0,12";

$P_results= mysqli_query($connection,$prod_sql);
if(mysqli_num_rows($P_results) > 0){
    while($row = mysqli_fetch_array($P_results)){
       $prod_id = $row["idProd"];
       $prod_category = $row["categoryProd"];
       $prod_volume = $row["volumeProd"];
        $prod_title = $row['titleProd'];
       $prod_price = $row["priceProd"];
       $prod_description = $row["descriptionProd"];
       $prod_image = $row["imageProd"];
       $prod_brand= $row["brandProduct"];
      echo "
       
    
      <div class='col-md-4' data-keywords='$prod_brand'>
                    <div class='panel panel-success'>
                      <div class='panel-heading description'>$prod_title</div>
                        <div class='panel-body' style=' height: 200px; overflow: hidden;'><a href='#'  class='each_product' ><img src='images/$prod_image'  class='img-thumbnail'/></a></div>
                         <div class='panel-heading'>$$prod_price
                          <button style='float:right;'  class='btn btn-danger btn-xs add_product' pid='$prod_id' id='$prod_id'>Add To Cart</button>
                        </div>
                    </div>    
            </div>
       
      ";
  }   
    
}
}

/*** the below code is to
 ** filter products by category
 ** display individual product
  ***/

if(isset($_POST["categories"])){
     $cid = $_POST["cat_id"];
   
     //select products based on specific category id
       $sql="SELECT * FROM products WHERE categoryProd ='$cid'";
        
    
    $results= mysqli_query($connection,$sql);
    
     while($row = mysqli_fetch_array($results)){
         $prod_id = $row["idProd"];
         $prod_category = $row["categoryProd"];
         $prod_volume = $row["volumeProd"];
         $prod_title = $row['titleProd'];
         $prod_price = $row["priceProd"];
         $prod_description = $row["descriptionProd"];
         $prod_image = $row["imageProd"];
         $prod_brand= $row["brandProduct"];
         
         echo "
       
    
      <div class='col-md-4' data-keywords='$prod_brand'>
                    <div class='panel panel-danger'>
                      <div class='panel-heading description'>$prod_title</div>
                        <div class='panel-body' style=' height: 200px; overflow: hidden;'>
                            <a href='#'  class='each_product' >
                            <img src='images/$prod_image'  class='img-thumbnail'/></a></div>
                            <div class='panel-heading'>$$prod_price
                            <button style='float:right;'  class='btn btn-dark btn-xs add_product' pid='$prod_id' id='$prod_id'>Add To Cart</button>
                        </div>
                    </div>    
            </div>
       
      "; 
         
     }
         
}

  
   /*** 
    *** in the code below
    the image is a link when clicking on it the individual product details will be displayed 
    ***/ 
  



/*
$pid = $_POST["img-thumbnail"];
//select products based on specific product id
$sql="SELECT * FROM product WHERE idProd ='$pid'";
$results= mysqli_query($connection,$sql);

 while($row = mysqli_fetch_array($results)){
     $prod_id = $row["idProd"];
     $prod_category = $row["categoryProd"];
     $prod_volume = $row["volumeProd"];
     $prod_title = $row['titleProd'];
     $prod_price = $row["priceProd"];
     $prod_description = $row["descriptionProd"];
     $prod_image = $row["imageProd"];
     $prod_brand= $row["brandProduct"];
  
             
    //  echo "

   /* <!--  <div class='col-md-4' data-keywords='$prod_keyword'>
                    <div class='panel panel-danger'>
                      <div class='panel-heading'>$prod_description</div>
                        <div class='panel-body' style=' height: 200px; overflow: hidden;'><a href='#' class='each_product' product_id='$prod_id'><img src='images/$prod_image' class='img-thumbnail'/></a></div>
                         <div class='panel-heading'>$$prod_price 
                          <button style='float:right;' class='btn btn-info btn-xs add_product' pid='$prod_id'>Add To Cart</button>
                        </div>
                    </div>    
            </div>
            ";
        }

*/










?>